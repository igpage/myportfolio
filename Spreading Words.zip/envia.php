<?php

require("class.phpmailer.php");
require("class.smtp.php");

if ( !isset($_POST["nombre"]) || !isset($_POST["email"]) || !isset($_POST["telefono"])  || !isset($_POST["empresa"])  || !isset($_POST["mensaje"]) ) {
    die ("Es necesario completar todos los datos del formulario");
}





$nombre = $_POST["nombre"];

$email = $_POST["email"];

$telefono = $_POST["telefono"];

$asunto = $_POST["empresa"];

$mensaje = $_POST["mensaje"];





$mail = new PHPMailer();
$mail->IsSMTP();                                      // Establecer envío SMTP
$mail->Host = "one.com";  // Especificar el servidor principal y de respaldo
$mail->SMTPAuth = true;     // Activar la autenticación SMTP
$mail->Username = "irene80294@alumnos.cei.es";  // SMTP nombre de usuario
$mail->Password = "Vad24261"; // SMTP contraseña

$mail->From = "irene80294@alumnos.cei.es";
$mail->FromName = "Mailer";
$mail->AddAddress("irene80294@alumnos.cei.es", "Comercial Spreading Words");        // opcional
$mail->AddReplyTo("irene80294@alumnos.cei.es", "Información");

$mail->WordWrap = 50;
$mail->IsHTML(true);                                  // Formato de correo electrónico listo para HTML

$mail->Subject = "Language services company Spreading Words";
$mail->Body    = "<html> 

<body> 

<h1>Recibiste un nuevo mensaje desde el formulario de contacto</h1>

<p>Informacion enviada por el usuario de la web:</p>

<p>nombre: {$nombre}</p>

<p>email: {$email}</p>

<p>telefono: {$telefono}</p>

<p>asunto: {$asunto}</p>

<p>mensaje: {$mensaje}</p>

</body> 

</html>

<br />";

$mail->AltBody = "Este es el cuerpo de texto sin formato para los clientes de correo no HTML";

if(!$mail->Send())
{
echo "El mensaje no se ha podido enviar. <p>";
echo "Error: " . $mail->ErrorInfo;
exit;
}

echo "<script>alert('¡El formulario se ha enviado con éxito!')</script>";
    echo("<script>window.location = 'index.html';</script>");
    
?>